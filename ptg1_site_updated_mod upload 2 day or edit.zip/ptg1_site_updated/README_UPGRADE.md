# PTG1 — Perfect Timing Gaming (Static Site)

This folder contains a complete upgraded static-site skeleton for **PTG1**.
Theme: **money green + gold + black**.

## How to apply
1. Download the zip from ChatGPT and extract it.
2. Copy these files into your repo root (overwrite existing root files):
   - index.html, style.css, app.js
   - lounge.html, services.html, signin.html
   - rules.html, seasons.html, sitemap.html, contact.html, about.html, faq.html
   - portal.html, ptg-admin.html, ptg-staff.html
   - 404.html, manifest.webmanifest, sw.js, robots.txt, sitemap.xml
   - assets/ptg-logo.svg, assets/favicon.svg
3. Commit + push to `main`.
4. Verify live:
   - Open your GitHub Pages site and hard refresh
   - Or add `?v=1` to bypass cache.

## Notes
- Forms are **mailto-based** (no backend required).
- The Portal gate is for **routing**, not security.
- If you add a page, update `sitemap.html` in the same commit.

Updated: 2026-01-08
