/* =========================================================
   PTG1 — Site JS
   - Mobile nav toggle
   - Mailto form builder (with safe encoding)
   - Small UX helpers
   ========================================================= */

(function () {
  "use strict";

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  // Mobile nav
  const navToggle = $("#navToggle");
  const navLinks = $("#navLinks");

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }

  // Highlight current nav link (for pages that forgot aria-current)
  const currentPath = location.pathname.split("/").pop() || "index.html";
  $$("#navLinks a[data-match]").forEach(a => {
    if (a.getAttribute("data-match") === currentPath) {
      a.setAttribute("aria-current", "page");
    }
  });

  // Mailto builder (PTG standard: green send button with 🎯)
  function encodeMailtoValue(str) {
    return encodeURIComponent(String(str || "").replace(/\r?\n/g, "\n"));
  }

  function buildMailto(to, subject, body) {
    const s = encodeMailtoValue(subject);
    const b = encodeMailtoValue(body);
    return `mailto:${to}?subject=${s}&body=${b}`;
  }

  // Hook any form with data-mailto-form
  $$("#ptgMailtoForm[data-mailto-form]").forEach(form => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();

      const to = form.getAttribute("data-to") || "ChangeTheWRLD@outlook.com";
      const subject = form.getAttribute("data-subject") || "PTG1 Message";
      const fields = $$("[name]", form)
        .filter(el => !el.disabled)
        .map(el => {
          const label = el.getAttribute("data-label") || el.name;
          const val = el.value || "";
          return `${label}: ${val}`;
        })
        .join("\n");

      const body = [
        "PTG1 CONTACT / SUBMISSION",
        "—",
        fields,
        "—",
        "Sent via GitHub Pages (mailto fallback)"
      ].join("\n");

      const href = buildMailto(to, subject, body);

      // Try opening mail app
      window.location.href = href;

      // UX: show a copy-to-clipboard fallback
      const fallback = $("#copyFallback");
      const textarea = $("#copyFallbackText");
      if (fallback && textarea) {
        textarea.value = body;
        fallback.hidden = false;
      }
    });
  });

  // Copy fallback button
  const copyBtn = $("#copyBtn");
  if (copyBtn) {
    copyBtn.addEventListener("click", async () => {
      const textarea = $("#copyFallbackText");
      if (!textarea) return;
      try {
        await navigator.clipboard.writeText(textarea.value);
        copyBtn.textContent = "Copied ✅";
        setTimeout(() => (copyBtn.textContent = "Copy message"), 1200);
      } catch {
        textarea.focus();
        textarea.select();
        document.execCommand("copy");
        copyBtn.textContent = "Copied ✅";
        setTimeout(() => (copyBtn.textContent = "Copy message"), 1200);
      }
    });
  }
})();
